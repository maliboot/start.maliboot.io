<?php
declare(strict_types=1);

namespace Module\Sample\Domain\Repository;

use MaliBoot\Cola\Domain\CommandRepositoryInterface;

/**
 * ExampleRepo.
 */
interface ExampleRepo extends CommandRepositoryInterface
{
}
